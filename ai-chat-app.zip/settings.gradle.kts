// Top-level settings file for the AI Chat App.
// This file simply declares the included modules.  There is only one module
// in this project: the Android application itself, located in the `app` folder.

rootProject.name = "ai-chat-app"
include(":app")